# Account Manager Site

Deployed using Next.js and Axios to connect to NocoDB.